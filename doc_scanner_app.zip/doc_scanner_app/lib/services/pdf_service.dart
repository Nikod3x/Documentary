import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class PdfService {
  static Future<File> generatePdf({
    required List<String> imagePaths,
    required String title,
  }) async {
    final pdf = pw.Document(
      theme: pw.ThemeData.withFont(
        base: pw.Font.helvetica(),
      ),
    );

    for (final imagePath in imagePaths) {
      final imageFile = File(imagePath);
      final imageBytes = await imageFile.readAsBytes();

      pw.MemoryImage pdfImage;
      try {
        pdfImage = pw.MemoryImage(imageBytes);
      } catch (e) {
        continue;
      }

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: pw.EdgeInsets.zero,
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Image(
                pdfImage,
                fit: pw.BoxFit.contain,
                width: PdfPageFormat.a4.width,
                height: PdfPageFormat.a4.height,
              ),
            );
          },
        ),
      );
    }

    final dir = await getApplicationDocumentsDirectory();
    final fileName = '${title.replaceAll(' ', '_')}_${DateTime.now().millisecondsSinceEpoch}.pdf';
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  static Future<void> sharePdf(File pdfFile, String title) async {
    await Share.shareXFiles(
      [XFile(pdfFile.path)],
      subject: title,
      text: 'Scanned document: $title',
    );
  }

  static Future<void> shareImages(List<String> imagePaths, String title) async {
    final xFiles = imagePaths.map((p) => XFile(p)).toList();
    await Share.shareXFiles(
      xFiles,
      subject: title,
      text: 'Scanned document: $title',
    );
  }
}
