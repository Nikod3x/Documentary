import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

enum FilterMode { original, blackWhite, enhanced, vivid }

class ImageService {
  static Future<File> applyFilter(String imagePath, FilterMode filter) async {
    final bytes = await File(imagePath).readAsBytes();
    img.Image? image = img.decodeImage(bytes);
    if (image == null) return File(imagePath);

    switch (filter) {
      case FilterMode.original:
        // slight auto-enhance
        image = img.adjustColor(image, contrast: 1.1);
        break;
      case FilterMode.blackWhite:
        image = img.grayscale(image);
        image = img.adjustColor(image, contrast: 1.6, brightness: 1.05);
        // Sharpen
        image = _sharpen(image);
        break;
      case FilterMode.enhanced:
        image = img.adjustColor(image, contrast: 1.4, saturation: 0.2, brightness: 1.1);
        image = _sharpen(image);
        break;
      case FilterMode.vivid:
        image = img.adjustColor(image, contrast: 1.3, saturation: 1.5, brightness: 1.05);
        break;
    }

    final dir = await getTemporaryDirectory();
    final outPath = '${dir.path}/filtered_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final outFile = File(outPath);
    await outFile.writeAsBytes(img.encodeJpg(image, quality: 92));
    return outFile;
  }

  static img.Image _sharpen(img.Image src) {
    return img.convolution(
      src,
      filter: [0, -1, 0, -1, 5, -1, 0, -1, 0],
      div: 1,
      offset: 0,
    );
  }

  static Future<String> saveToDocuments(String tempPath, String name) async {
    final dir = await getApplicationDocumentsDirectory();
    final dest = '${dir.path}/${name}_${DateTime.now().millisecondsSinceEpoch}.jpg';
    await File(tempPath).copy(dest);
    return dest;
  }
}
