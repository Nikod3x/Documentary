import 'dart:io';
import 'package:flutter/material.dart';
import '../main.dart';
import '../models/scanned_document.dart';
import '../models/document_provider.dart';
import '../services/pdf_service.dart';
import '../services/image_service.dart';
import 'image_viewer_screen.dart';

class DocumentDetailScreen extends StatefulWidget {
  final ScannedDocument document;
  final DocumentProvider provider;

  const DocumentDetailScreen({
    super.key,
    required this.document,
    required this.provider,
  });

  @override
  State<DocumentDetailScreen> createState() => _DocumentDetailScreenState();
}

class _DocumentDetailScreenState extends State<DocumentDetailScreen> {
  late ScannedDocument _doc;
  bool _isExporting = false;
  FilterMode _activeFilter = FilterMode.original;
  int _selectedPage = 0;

  @override
  void initState() {
    super.initState();
    _doc = widget.document;
  }

  Future<void> _exportPdf() async {
    setState(() => _isExporting = true);
    try {
      final pdfFile = await PdfService.generatePdf(
        imagePaths: _doc.imagePaths,
        title: _doc.title,
      );

      final updated = ScannedDocument(
        id: _doc.id,
        title: _doc.title,
        imagePaths: _doc.imagePaths,
        createdAt: _doc.createdAt,
        pdfPath: pdfFile.path,
      );
      widget.provider.updateDocument(updated);
      setState(() => _doc = updated);

      await PdfService.sharePdf(pdfFile, _doc.title);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Export failed: $e'),
            backgroundColor: Colors.red.shade800,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _shareImages() async {
    try {
      await PdfService.shareImages(_doc.imagePaths, _doc.title);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Share failed: $e'), backgroundColor: Colors.red.shade800),
        );
      }
    }
  }

  Future<void> _applyFilter(FilterMode filter) async {
    if (_activeFilter == filter) return;
    setState(() => _activeFilter = filter);

    // Show visual feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
            const SizedBox(width: 12),
            Text('Applying ${_filterName(filter)} filter...'),
          ],
        ),
        duration: const Duration(seconds: 2),
        backgroundColor: AppTheme.card,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String _filterName(FilterMode f) {
    switch (f) {
      case FilterMode.original: return 'Original';
      case FilterMode.blackWhite: return 'B&W';
      case FilterMode.enhanced: return 'Enhanced';
      case FilterMode.vivid: return 'Vivid';
    }
  }

  IconData _filterIcon(FilterMode f) {
    switch (f) {
      case FilterMode.original: return Icons.crop_original;
      case FilterMode.blackWhite: return Icons.contrast;
      case FilterMode.enhanced: return Icons.auto_fix_high;
      case FilterMode.vivid: return Icons.palette;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: CustomScrollView(
        slivers: [
          // App bar
          SliverAppBar(
            pinned: true,
            backgroundColor: AppTheme.bg,
            leading: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.card,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.arrow_back, size: 20),
              ),
              onPressed: () => Navigator.pop(context),
            ),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_doc.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                Text(_doc.pageLabel, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.share_outlined),
                onPressed: _shareImages,
                tooltip: 'Share images',
              ),
              const SizedBox(width: 8),
            ],
          ),

          // Main image preview
          SliverToBoxAdapter(
            child: _buildMainPreview(),
          ),

          // Page thumbnails
          if (_doc.pageCount > 1)
            SliverToBoxAdapter(child: _buildPageStrip()),

          // Filter bar
          SliverToBoxAdapter(child: _buildFilterBar()),

          // Action buttons
          SliverToBoxAdapter(child: _buildActions()),

          // Info card
          SliverToBoxAdapter(child: _buildInfoCard()),

          const SliverToBoxAdapter(child: SizedBox(height: 40)),
        ],
      ),
    );
  }

  Widget _buildMainPreview() {
    final path = _doc.imagePaths[_selectedPage];
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ImageViewerScreen(
            imagePaths: _doc.imagePaths,
            initialIndex: _selectedPage,
          ),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        height: 480,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppTheme.accent.withOpacity(0.15),
              blurRadius: 40,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.file(
                File(path),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: AppTheme.card,
                  child: const Icon(Icons.broken_image, color: AppTheme.textSecondary, size: 48),
                ),
              ),
              // Tap to expand hint
              Positioned(
                right: 12,
                top: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.zoom_in, size: 14, color: Colors.white),
                      SizedBox(width: 4),
                      Text('Expand', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
              if (_doc.pageCount > 1)
                Positioned(
                  bottom: 12,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_doc.pageCount, (i) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: i == _selectedPage ? 20 : 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: i == _selectedPage ? AppTheme.accent : Colors.white38,
                        borderRadius: BorderRadius.circular(3),
                      ),
                    )),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPageStrip() {
    return SizedBox(
      height: 90,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _doc.pageCount,
        itemBuilder: (_, i) {
          final isSelected = i == _selectedPage;
          return GestureDetector(
            onTap: () => setState(() => _selectedPage = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 60,
              margin: const EdgeInsets.only(right: 10, bottom: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? AppTheme.accent : Colors.transparent,
                  width: 2,
                ),
                boxShadow: isSelected ? [
                  BoxShadow(color: AppTheme.accent.withOpacity(0.3), blurRadius: 8),
                ] : null,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.file(
                  File(_doc.imagePaths[i]),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: AppTheme.card,
                    child: const Icon(Icons.image, color: AppTheme.textSecondary, size: 20),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFilterBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'FILTER',
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: FilterMode.values.map((filter) {
              final isActive = _activeFilter == filter;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => _applyFilter(filter),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: isActive ? AppTheme.accent : AppTheme.card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isActive ? AppTheme.accent : AppTheme.border,
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            _filterIcon(filter),
                            size: 20,
                            color: isActive ? Colors.white : AppTheme.textSecondary,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _filterName(filter),
                            style: TextStyle(
                              color: isActive ? Colors.white : AppTheme.textSecondary,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildActions() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: _isExporting
                ? Container(
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppTheme.accent.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Center(
                      child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                      ),
                    ),
                  )
                : ElevatedButton.icon(
                    onPressed: _exportPdf,
                    icon: const Icon(Icons.picture_as_pdf, size: 20),
                    label: const Text('Export PDF'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(0, 56),
                      backgroundColor: AppTheme.accent,
                    ),
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _shareImages,
              icon: const Icon(Icons.ios_share, size: 18),
              label: const Text('Share'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 56),
                backgroundColor: AppTheme.card,
                foregroundColor: AppTheme.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'DOCUMENT INFO',
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          _infoRow(Icons.insert_drive_file_outlined, 'Name', _doc.title),
          const Divider(color: AppTheme.border, height: 24),
          _infoRow(Icons.layers_outlined, 'Pages', _doc.pageLabel),
          const Divider(color: AppTheme.border, height: 24),
          _infoRow(Icons.schedule_outlined, 'Created', _doc.formattedDate),
          if (_doc.pdfPath != null) ...[
            const Divider(color: AppTheme.border, height: 24),
            _infoRow(Icons.check_circle_outline, 'PDF', 'Exported'),
          ],
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppTheme.accent),
        const SizedBox(width: 12),
        Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
