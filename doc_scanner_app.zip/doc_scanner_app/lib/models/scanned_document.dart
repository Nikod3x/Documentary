import 'dart:io';

class ScannedDocument {
  final String id;
  final String title;
  final List<String> imagePaths;
  final DateTime createdAt;
  String? pdfPath;

  ScannedDocument({
    required this.id,
    required this.title,
    required this.imagePaths,
    required this.createdAt,
    this.pdfPath,
  });

  int get pageCount => imagePaths.length;

  File get thumbnailFile => File(imagePaths.first);

  String get formattedDate {
    final now = DateTime.now();
    final diff = now.difference(createdAt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
  }

  String get pageLabel => pageCount == 1 ? '1 page' : '$pageCount pages';
}
