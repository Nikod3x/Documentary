import 'package:flutter/foundation.dart';
import '../models/scanned_document.dart';

class DocumentProvider extends ChangeNotifier {
  final List<ScannedDocument> _documents = [];

  List<ScannedDocument> get documents => List.unmodifiable(_documents);

  void addDocument(ScannedDocument doc) {
    _documents.insert(0, doc);
    notifyListeners();
  }

  void updateDocument(ScannedDocument updated) {
    final idx = _documents.indexWhere((d) => d.id == updated.id);
    if (idx != -1) {
      _documents[idx] = updated;
      notifyListeners();
    }
  }

  void deleteDocument(String id) {
    _documents.removeWhere((d) => d.id == id);
    notifyListeners();
  }

  void renameDocument(String id, String newTitle) {
    final idx = _documents.indexWhere((d) => d.id == id);
    if (idx != -1) {
      final doc = _documents[idx];
      _documents[idx] = ScannedDocument(
        id: doc.id,
        title: newTitle,
        imagePaths: doc.imagePaths,
        createdAt: doc.createdAt,
        pdfPath: doc.pdfPath,
      );
      notifyListeners();
    }
  }
}
