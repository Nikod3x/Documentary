# ScanDoc - Flutter Document Scanner App

A professional document scanner app with PDF export, filters, and sharing.

## Features
- 📄 Scan documents using device camera
- 🖼 Import from gallery
- 📑 Multi-page scanning (up to 20 pages)
- 🎨 Filters: Original, B&W, Enhanced, Vivid
- 📤 Export to PDF
- 📱 Share as PDF or images
- 🔍 Full-screen image viewer with pinch-to-zoom
- ✏️ Rename & delete documents
- 🌙 Dark UI

---

## Setup & Build Instructions

### Prerequisites
- Flutter SDK ≥ 3.0.0 (https://docs.flutter.dev/get-started/install)
- Xcode (for iOS) or Android Studio (for Android)
- A physical device (recommended — camera required)

### 1. Install dependencies
```bash
flutter pub get
```

### 2. Run on device
```bash
# List connected devices
flutter devices

# Run on your device
flutter run --release
```

### 3. Build APK (Android)
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

### 4. Build for iOS
```bash
flutter build ios --release
# Then open ios/Runner.xcworkspace in Xcode and archive
```

---

## Android Notes
- Minimum SDK: 21
- Targets SDK: 34
- Camera + Storage permissions requested at runtime

## iOS Notes
- Minimum iOS: 12.0
- Camera and Photo Library permissions in Info.plist
- Uses VisionKit for document edge detection

---

## Project Structure
```
lib/
├── main.dart                    # App entry, theme
├── models/
│   ├── scanned_document.dart    # Document data model
│   └── document_provider.dart  # State management
├── services/
│   ├── pdf_service.dart         # PDF generation & sharing
│   └── image_service.dart       # Filters & image processing
├── screens/
│   ├── home_screen.dart         # Document list
│   ├── document_detail_screen.dart  # View/export document
│   └── image_viewer_screen.dart     # Full-screen viewer
└── widgets/
    ├── document_card.dart       # List item card
    ├── empty_state.dart         # Empty list view
    └── scan_fab.dart            # Animated scan button
```

---

## Troubleshooting

**Camera not working?**
- Make sure you're on a real device, not a simulator
- Accept camera permission when prompted

**Build errors?**
```bash
flutter clean
flutter pub get
flutter run
```

**iOS pod issues?**
```bash
cd ios && pod install && cd ..
```
